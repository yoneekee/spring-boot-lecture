package com.jjang051.gallery.dto;

import lombok.Data;

@Data
public class ReplyDto {

  private int no;
  private int galleryId;
  private String comments;
}
