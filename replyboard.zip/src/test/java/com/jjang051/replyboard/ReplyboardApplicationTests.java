package com.jjang051.replyboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReplyboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
