package com.jjang051.replyboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReplyboardApplication {

  public static void main(String[] args) {
    SpringApplication.run(ReplyboardApplication.class, args);
  }
}
